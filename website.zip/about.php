<?php

$title = 'About us | Residential Construction Companies in Bangalore';
$description = 'Learn about Atha Construction, the most reputable residential construction companies in Bangalore, which produces high-quality homes with creativity and skill.';
$keywords = 'residential construction companies in bangalore, Home Construction contractors In Bangalore, Atha construction in bangalore';
$h1 = "Atha Construction: Built on Experience, Driven by Vision";

include 'header.php';
?>

<section class="sec-banner">
    <div class="bnr-img">
        <img src="./assetes/images/about/about-banner.png" class="w-100" alt="house construction in bangalore" title="house construction in bangalore">

        <div class="bg-bnr-layer">

        </div>

       

        <div class="baner-cont-abs1 d-lg-block d-none">
            <h1>
                <?php echo $h1; ?>
            </h1>
            <!-- <p class="bnr-sub-cont">
                Tomer Fridman | CA DRE# 01750717
            </p>

            <button>
                EXPLORE
            </button> -->

        </div>

        

    </div>
</section>

<section class="sec over-sec text-center" id="next-section">

    <div class="over-sec2  py-5"> 
        <div class="container">

            <h2 class="mn-hed">
                EXPERTISE. PROFESSIONALISM. DEDICATION.
            </h2>

            <p class="secSub-hed pt-3 d-block mx-auto">
                The ATHA Construction offers an unparalleled level of service, expertise and discretion to its clients, buyers and
                sellers alike, across the globe.
            </p>

            <div class="row pt-5 d-flex justify-content-center">

                <div class="col-lg-3 col-4">
                    <p class="hed-num">
                    8+
                    </p>
                    <p class="num-cont"> Years of Experience </p>
                </div>
                <div class="col-lg-3 col-4">
                    <p class="hed-num">
                    2M+
                    </p>
                    <p class="num-cont">Sq.Ft Developed</p>
                </div>
                <div class="col-lg-3 col-4">
                    <p class="hed-num">
                    500+
                    </p>
                    <p class="num-cont">
                    Completed Projects
                    </p>
                </div>

            </div>

        </div>
    </div>
</section>

<section class="sec py-5">

    <div class="container">
        <div class="row d-flex justify-content-between align-items-center">


            <div class="col-lg-4">
                <img src="./assetes/images/about/about.jpg" class="w-100" alt="Villa Construction Company In Ballari" title="Villa Construction Company In Ballari">
            </div>

            <div class="col-lg-7 pe-lg-5">
                <!-- <p class="secSub-hed mb-1">
                    ABOUT
                </p> -->
                <h2 class="mn-hed">
                    Atha Construction: Built on Experience, Driven by Vision
                </h2>

                <p class="cm-fnt txt-just pt-3">
                
                Eight years ago, Atha Construction emerged from Mr. Arun’s determination to resolve the challenges he faced in his own construction projects. Frustrated by delays, mismanagement, and cost overruns, he envisioned a company that would offer a seamless, transparent, and hassle-free experience, moving beyond the limitations of individual contractors.
                </p>

                <p class="cm-fnt txt-just">
                What began as a personal mission grew into a commitment to revolutionize the construction industry. Atha Construction redefined excellence by integrating advanced technology, sustainable practices, and a client-first approach to create inspiring spaces and foster community.
                </p>

                <p class="cm-fnt txt-just">
                Today, Atha Construction is a trusted name in the industry, founded on innovation and reliability. Mr. Arun’s vision has transformed countless dreams into reality, establishing a legacy built on trust and exceptional value.
                </p>

            </div>

        </div>
        <hr>
    </div>

</section>

<section class="sec py-lg-5">

    <div class="container pt-lg-2 pb-lg-3">
       



        <h2 class="mn-hed text-center mb-4">
            OUR PHILOSOPHY
        </h2>

            <div>
               
               

                <p class="cm-fnt2">
                 <i class="fa fa-solid fa-quote-left"></i> 
                  <span class="pt-5 mb-2 ">  We believe construction is more than building structures; it’s about creating meaningful spaces <br> that foster growth, comfort, and trust.</span>
                    <i class="fa fa-solid fa-quote-right"></i>
                </p>

            </div>

            
   
    </div>

</section>



<section class="sec py-5">

    <div class="container">
       



        <!-- <h2 class="mn-hed text-center">
            OUR MISSION AND VISION 
        </h2> -->

            <div class="row">
               
               <div class="col-lg-6 mb-5 mb-lg-0">
                    <div class="mis-vis mis">
                        <img src="assetes\images\about\mission.svg" class="m-v" alt="">

                        <h5 class="text-center mt-4">OUR MISSION </h5>

                        <p class="cm-fnt text-center ">
                              Craft spaces that reflect the unique needs and aspirations of our clients while building relationships founded on trust and collaboration.

                        </p>

                        <p class="cm-fnt text-center">

                            To deliver exceptional construction services that exceed expectations, providing value and lasting quality in every project.
                        </p>
                    </div>
               </div>


               <div class="col-lg-6">
                    <div class="mis-vis vis">
                        <img src="assetes\images\about\vision.svg" class="m-v" alt="">

                        <h5 class="text-center mt-4">OUR VISION</h5>
                        <p class="cm-fnt text-center">
                            To be the most trusted and innovative construction partner, shaping inspiring spaces that stand as a testament to quality, collaboration, and enduring value. We envision a future where every project fosters strong relationships and enriches the lives of our clients and communities.
                        </p>
                    </div>
               </div>

            </div>

            
   
    </div>

</section>



<section class="sec py-5">

    <div class="container">
        <div class="row align-items-center justify-content-center">
            <div class="col-md-12 text-center">
                <h2 class="mn-hed pb-4">
                    Our USP's
                </h2>
            </div>
            <div class="col-lg-6 pe-lg-5">
                <!-- <p class="secSub-hed mb-1">
                    ABOUT
                </p> -->              

                <p class="wu-h">
                Transparency, No Hidden Charges
                </p>
                

                <p class="wu-h">
                Uncompromising Premium Quality <br/>Crafted with top tier material and exceptional Workmanship.
                </p>
                


                <p class="wu-h">
                Punctual Project Completion 
                </p>

                <p class="wu-h">
                All in One Elite Services
                </p>
                <p class="wu-h">
                Exclusive In- House Expertise  
                </p>

                <p class="wu-h">
                Fixed Pricing , Unified Team 
                </p>

                <p class="wu-h">
                Use only Branded Material
                </p>

                <p class="wu-h">
                Camera at Site and Allocated Site Engineers
                </p>

                

                


            </div>
            <div class="col-lg-6">
                <div id="carouselExample" class="carousel slide" data-bs-ride="carousel">
                    <div class="carousel-inner">
                        <div class="carousel-item active">
                            <img src="assetes/images/about/USP1.jpg" class="d-block w-100" alt="Slide 1">
                        </div>
                        <div class="carousel-item">
                            <img src="assetes/images/about/USP2.jpg" class="d-block w-100" alt="Slide 2">
                        </div>
                        <div class="carousel-item">
                            <img src="assetes/images/about/USP3.jpg" class="d-block w-100" alt="Slide 3">
                        </div>
                    </div>
                    <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
                        <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Previous</span>
                    </button>
                    <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
                        <span class="carousel-control-next-icon" aria-hidden="true"></span>
                        <span class="visually-hidden">Next</span>
                    </button>
                </div>
            </div>

        </div>
    </div>

</section>


<section class="py-lg-5">
    <div class="container">
        <div class="row text-center">
            <div class="col-md-12">
                <h2 class="mn-hed mb-5">OUR FOUNDERS</h2>
            </div>            
        </div> 
        <div class="row justify-content-center">
            <div class="col-md-4 col-12 mb-4 mb-md-0 px-4 ">
                <img src="assetes/img/1.jpg" class=" img-fluid d-block mx-auto">
                <h4 class="text-center mt-4">Arun A R (MD & CEO) </h4>
                <p class="txt-just cm-fnt ">With over a decade of diverse experience in real estate development and property management, Arun A R brings visionary leadership and a deep understanding of the construction industry. His expertise lies in crafting innovative strategies and ensuring the seamless execution of projects. Under his guidance, the company has consistently delivered value-driven, high-quality developments, setting benchmarks for excellence and trust in the industry. His commitment to integrity and forward-thinking approaches continues to inspire the team and drive the company’s growth.</p>
            </div>
            <div class="col-md-4 col-12 mb-4 mb-md-0 px-4 ">
                <img src="assetes/img/2.jpg" class=" img-fluid d-block mx-auto">
                <h4 class="text-center mt-4">Lavanya G V (COO)</h4>
                <p class="txt-just  cm-fnt">Lavanya G V combines technical expertise with artistic vision to create exceptional spaces that reflect innovation and functionality. With a keen focus on client satisfaction and operational efficiency, she ensures every project aligns with the company’s commitment to quality and excellence. Her ability to seamlessly blend creativity with practical solutions has been instrumental in driving the success of numerous developments. Passionate about sustainability and design, she plays a pivotal role in shaping spaces that inspire and resonate with both clients and communities.</p>
            </div>
            <div class="col-md-4 col-12 mb-4 mb-md-0 px-4 ">
                <img src="assetes/img/3.jpg" class=" img-fluid d-block mx-auto">
                <h4 class="text-center mt-4">Vijaykumar N (VP)</h4>
                <p class="txt-just cm-fnt">Brings decades of experience and a track record of involvement in global iconic projects. With meticulous attention to detail and a strategic mindset honed over 40 years of experience, he has consistently guided projects to successful completion. His involvement in shaping iconic structures like the Burj Khalifa and Dubai Mall exemplifies his unwavering commitment to excellence and his skill in managing complex, large-scale endeavors with finesse.</p>
            </div>                    
            
            
            
        </div>
    </div>
</section>


<?php
include 'footer.php';
?>