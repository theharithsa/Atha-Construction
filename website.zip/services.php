<?php

$title = 'Atha Construction services | Home architecture design';
$description = 'Atha Construction offers expert home architecture design services, blending creativity and functionality to bring your dream home to life. Contact us for customized solutions!';
$keywords = 'Home Architecture Design, Home Construction Services in Ballari';
$h1 = "";

include 'header.php';
?>

<style>
    .bg{
        width:100%;
        height: 350px;
        background-color: lightgray;
    }

    .img-fluid w-100 {
        max-width: 100%;
        height: auto;
    }
</style>

<section class="sec-banner">
    <div class="bnr-img">
        <img src="./assetes/images/services-banner.png" class="w-100" alt="Home Construction Company in Bangalore" title="Home Construction Company in Bangalore">

        <div class="bg-bnr-layer">

        </div>

        <div class="baner-cont-abs1 d-lg-block d-none">
            <h1>
                Experience the Comfort
            </h1>
        </div>

        

    </div>
</section>

<section class="sec over-sec text-center" id="next-section">

    <div class="over-sec2  py-5"> 
        <div class="container">

            <h2 class="mn-hed">
                EXPERTISE. PROFESSIONALISM. DEDICATION.
            </h2>

            <p class="secSub-hed pt-3 d-block mx-auto">
                The ATHA Construction offers an unparalleled level of service, expertise and discretion to its clients, buyers and
                sellers alike, across the globe.
            </p>

            <div class="row pt-5 d-flex justify-content-center">

                <div class="col-lg-3 col-4">
                    <p class="hed-num">
                    8+
                    </p>
                    <p class="num-cont"> Years of Experience </p>
                </div>
                <div class="col-lg-3 col-4">
                    <p class="hed-num">
                    2M+
                    </p>
                    <p class="num-cont">Sq.Ft Developed</p>
                </div>
                <div class="col-lg-3 col-4">
                    <p class="hed-num">
                    500+
                    </p>
                    <p class="num-cont">
                    Completed Projects</p>
                </div>

            </div>

        </div>
    </div>
</section>


<section>
    <div class="container py-5">

        <div class="col-md-12 text-center">
            <h2 class="mn-hed mb-5">OUR SERVICES</h2>
        </div>

        <div class="row d-flex align-items-center">
            <div class="col-lg-6 order-2 order-md-1">
                <h3 class="pt-4 pt-lg-0">
                    Turnkey Construction
                </h3>

                <p>
                    Comprehensive construction services from start to finish, ensuring hassle-free project delivery. From site preparation to final handover, we promise smooth execution with attention to detail, quality, and timelines, making your dream home a seamless reality.
                </p>

            </div>

            <div class="col-lg-6 order-1 order-md-2">
                
              
                <img src="<?php echo BASE_URL; ?>assetes/images/Turnkey-Construction.jpg" alt="img-fluid w-100" style="width: 100%;"> 

            </div>

        </div>

        <div class="row d-flex align-items-center pt-5">
            <div class="col-lg-6 ">                
                
                <img src="<?php echo BASE_URL; ?>assetes/images/Architecture-&-Design.jpg" alt="img-fluid w-100" style="width: 100%;">

            </div>

            <div class="col-lg-6">
                <h3 class="pt-4 pt-lg-0">
                    Architecture & Design
                </h3>

                <p>
                Crafting exclusive designs with precision, including 2D, 3D, and GFC plans. Our designs blend your vision, Vastu principles, and functionality to create spaces that are both aesthetically pleasing and perfectly suited to your needs.
                </p>

            </div>
        </div>

        <div class="row d-flex align-items-center pt-5">
            <div class="col-lg-6 order-2 order-md-1">
                <h3 class="pt-4 pt-lg-0">
                    Project Management
                </h3>

                <p>
                
                
                Expert project management services ensure timely approvals, meticulous quality control, and efficient timelines. We handle every detail with professionalism, so you can enjoy a stress-free construction experience with seamless coordination and superior results.
                </p>

            </div>

            <div class="col-lg-6 order-1 order-md-2">
                
                <img src="<?php echo BASE_URL; ?>assetes/images/Project-Management.jpg" alt="img-fluid w-100" style="width: 100%;">

            </div>

        </div>


        <div class="row d-flex align-items-center pt-5">
            <div class="col-lg-6 ">
                
                <img src="<?php echo BASE_URL; ?>assetes/images/Interior-Design-&-Finishing.jpg" alt="img-fluid w-100" style="width: 100%;">

            </div>

            <div class="col-lg-6">
                <h3 class="pt-4 pt-lg-0">
                    Interior Design & Finishing
                </h3>

                <p>
                Transform your home with elegant interiors, including modular kitchens, custom wardrobes, and optimized layouts. Our tailored designs combine functionality with style to make every corner of your space both beautiful and practical.

                </p>

            </div>
        </div>
      
        
        <div class="row d-flex align-items-center pt-5">
            <div class="col-lg-6 order-2 order-md-1">
                <h3 class="pt-4 pt-lg-0">
                    Premium Materials and Craftsmanship
                </h3>

                <p>
                We use trusted brands like UltraTech Cement, JSW Steel, and Asian Paints to guarantee lasting quality. Our commitment to superior materials and expert craftsmanship ensures a durable and elegant finish for every project.
                </p>

            </div>

            <div class="col-lg-6 order-1 order-md-2">
                
                <img src="<?php echo BASE_URL; ?>assetes/images/Premium-Materials-and-Craftsmanship.jpg" alt="img-fluid w-100" style="width: 100%;">

            </div>

        </div>


        
        <div class="row d-flex align-items-center pt-5">
            <div class="col-lg-6 ">
                
                <img src="<?php echo BASE_URL; ?>assetes/images/Extra-Features.jpg" alt="img-fluid w-100" style="width: 100%;">

            </div>

            <div class="col-lg-6">
                <h3 class="pt-4 pt-lg-0">
                    Extra Features
                </h3>

                <p>
                    Elevate your home with seismic-resistant structures, future expansion readiness, and luxurious interiors on request. Our thoughtful additions prioritize safety, flexibility, and elegance, ensuring your home is prepared for tomorrow’s needs.
                </p>

            </div>
        </div>
      

        <div class="row d-flex align-items-center pt-5">
            <div class="col-lg-6 order-2 order-md-1">
                <h3 class="pt-4 pt-lg-0">
                 Home Automation 
                 <!-- of Process -->
                </h3>

                <p>
                 Incorporate cutting-edge smart systems and IoT integration into your home. Experience modern living with advanced automation, enabling seamless control of lighting, security, and appliances for unmatched convenience and efficiency.

                </p>

            </div>

            <div class="col-lg-6 order-1 order-md-2">
                
                <img src="<?php echo BASE_URL; ?>assetes/images/Automation-of-Process.jpg" alt="img-fluid w-100" style="width: 100%;">

            </div>

        </div>


        <div class="row d-flex align-items-center pt-5">
            <div class="col-lg-6 ">
                
                <img src="<?php echo BASE_URL; ?>assetes/images/Amenities.jpg" alt="img-fluid w-100" style="width: 100%;">

            </div>

            <div class="col-lg-6">
                <h3 class="pt-4 pt-lg-0">
                    Amenities
                </h3>

                <p>
                    Personalize your property with custom amenities like high-speed Wi-Fi, landscaped gardens, and recreational spaces. We design features that enhance your lifestyle, creating a perfect balance of comfort, functionality, and leisure.
                </p>

            </div>
        </div>

        
    </div>
</section>


<?php
include 'footer.php';
?>