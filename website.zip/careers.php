<?php

$title = 'Atha construction |Atha construction Carrer';
$description = 'Explore exciting career opportunities with Atha Construction. Join our dynamic team and build your future with a leading name in the construction industry.';
$keywords = 'Top Construction Company In Ballari, Home Construction In Ballari, Construction Companies In Bangalore, Villa Construction Company In Bangalore';
$h1 = "Atha construction Carrer";

include 'header.php';
?>







<style>
    #google_translate_element {
        position: absolute;
        right: 0;
        top: -40px;
    }

    @media only screen and (max-width:768px) {
        #google_translate_element {
            position: absolute;
            right: 0;
            top: 85px;
        }
    }

    .text-justify {
        text-align: justify !important;
    }
</style>




<div class="animsition boxed blog">


    <style>
        .int_about_style2 .about_contentbox {
            padding: 0px 30px 0px 30px;
        }

        .contact-form {
            position: relative;
            z-index: 1;
        }

        .formspace {
            padding: 30px 20px;
            border: 1px solid #dfdfdf;
            box-shadow: 0px 0px 20px 0px rgb(1 1 1 / 10%);
            background: #dfdfdf;
        }

        .mb-20 {
            margin-bottom: 20px;
        }

        .contact-field input {
            width: 100%;
            border: none;
            background: #fff;
            padding: 7px 20px;
            margin-bottom: 4%;
            transition: .3s;
            border: 1px solid #dfdfdf;
        }

        #careers .inputWithIcon i {
            position: absolute;
            left: 0;
            top: 17px;
            padding: 4px 25px;
            color: #CCCCCC;
            transition: 0.3s;
        }

        #careers .custom-select {
            height: 45px;
            padding: 0px 40px;
            color: #202020;
            border: none;
        }

        #careers .contact-field .inputWithIcon i {
            padding: 4px 13px;
        }


        .contact-field textarea {
            width: 100%;
            border: none;
            background: #fff;
            padding: 15px 40px;
            /* transition: .3s; */
            border: 1px solid #dfdfdf;
            color: #9e9e9e;
        }

        .file-upload-wrapper {
            position: relative;
            width: 100%;
            height: 60px;
            background: #fff;
        }

        .file-upload-wrapper:after {
            content: attr(data-text);
            font-size: 18px;
            position: absolute;
            top: 0;
            left: 0;
            background: #fff;
            padding: 10px 15px;
            display: block;
            width: calc(100% - 40px);
            pointer-events: none;
            z-index: 20;
            height: 40px;
            line-height: 40px;
            color: #999;
            border-radius: 5px 10px 10px 5px;
            font-weight: 300;
        }

        .file-upload-wrapper:before {
            content: "Upload Resume";
            position: absolute;
            top: 0;
            right: 0;
            display: inline-block;
            height: 60px;
            background: black;
            color: white;
            color: #fff;
            font-weight: 700;
            z-index: 25;
            font-size: 16px;
            line-height: 60px;
            padding: 0 15px;
            text-transform: uppercase;
            pointer-events: none;
            border-radius: 0 5px 5px 0;
        }

        .file-upload-wrapper:hover:before {
            background: #555555;
        }

        .file-upload-wrapper input {
            opacity: 0;
            position: absolute;
            top: 0;
            right: 0;
            bottom: 0;
            left: 0;
            z-index: 99;
            height: auto;
            margin: 0;
            padding: 0;
            display: block;
            cursor: pointer;
            width: 100%;
        }

        .panel-heading {
            padding-top: 10px;
        }

        .panel-body {
            box-shadow: 0px 0px 20px 0px rgb(1 1 1 / 10%);
            padding: 15px;
        }

        .panel-body p {
            color: #222;
            margin-bottom: 15px;
        }

        .panel-title>a,
        .panel-title>a:active {
            display: block;
            padding: 20px;
            color: #fff;
            font-size: 16px;
            font-weight: bold;
            text-transform: uppercase;
            letter-spacing: 1px;
            word-spacing: 3px;
            text-decoration: none;
            background: #555555;
        }



        .panel-heading a.collapsed:before {
            -webkit-transform: rotate(180deg);
            -moz-transform: rotate(180deg);
            transform: rotate(180deg);
        }

        .contact-field label {
            display: block;
            font-size: 16px;
            font-weight: 500;
            text-transform: none;
            color: #ff0000;
            cursor: unset;
        }

        .contact-field label {
            display: block;
            font-size: 16px;
            font-weight: 500;
            cursor: unset;
        }

        #fileUpload-error {
            display: none;
        }

        .error {
            padding: 0px 0 0 10px;
            margin-bottom: 0.75rem;
            text-shadow: 0 1px 0 rgb(255 255 255 / 50%);
            color: #b94a48;
            background-color: #f2dede;
            border: 1px solid rgba(185, 74, 72, 0.3);
            width: 100%;
        }

        .input-group>.custom-select {
            /*margin-bottom: 0.75rem;*/
        }

        #inputGroupSelect01-error {
            margin-top: 0.75rem;
        }

        #inputGroupSelect02-error {
            margin-top: 0.75rem;
        }
    </style>


    <section class="sec-banner">
        <div class="bnr-img">
            <img src="./assetes/images/about/about-banner.png" class="w-100" alt="">

            <div class="bg-bnr-layer">

            </div>


            <div class="baner-cont-abs1 d-lg-block d-none">
                <h1>
                    Atha construction Carrer
                </h1>
              

            </div>

           

        </div>
    </section>

    <section class="careers py-md-5 py-0 mt-5 portfolio career" style="overflow-x:hidden !important ;" id="next-section">
        <div class="int_blog_category texture">
            <div class="container">

                <div class="row">

                    <div class="col-md-6 wow slideInLeft animated"
                        style="visibility: visible; animation-name: slideInLeft;">
                        <div class="wrapper center-block">
                            <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
                                <div class="panel panel-default">
                                    <div class="panel-heading active" role="tab" id="headingOn">
                                        <h4 class="panel-title">
                                            <a role="button" data-bs-toggle="collapse" data-bs-parent="#accordion"
                                                href="#collapseOn" aria-expanded="true" aria-controls="collapseOn"
                                                class=""> Sales</a>
                                        </h4>
                                    </div>
                                    <div id="collapseOn" class="panel-collapse in collapse show" role="tabpanel"
                                        aria-labelledby="headingOn" style="">
                                        <div class="panel-body">
                                            <p>Dynamic and highly energetic individuals are needed who have pleasing personality as well as good communication skills. Preference will be given to people with call center experience.</p>
                                            <ul class="text-dark">
                                                <li>Qualification: Graduate </li>
                                                <li>Min. Experience: 1 year</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingOne">
                                        <h4 class="panel-title">
                                            <a  class="collapsed" role="button" data-bs-toggle="collapse" data-bs-parent="#accordion"
                                                href="#collapseOne" aria-expanded="true" aria-controls="collapseOne"> Architect</a>
                                        </h4>
                                    </div>
                                    <div id="collapseOne" class="panel-collapse collapse" role="tabpanel"
                                        aria-labelledby="headingOne" style="">
                                        <div class="panel-body">
                                            <p>Design innovative and functional spaces, ensuring aesthetic and structural excellence in all projects.</p>
                                            <ul class="text-dark">
                                                <li>Qualification: Graduate </li>
                                                <li>Min. Experience: 4 years</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <!-- Jr. Architect  -->
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingFour">
                                        <h4 class="panel-title">
                                            <a  class="collapsed" role="button" data-bs-toggle="collapse" data-bs-parent="#accordion"
                                                href="#collapseFour" aria-expanded="true" aria-controls="collapseFour">Jr. Architect </a>
                                        </h4>
                                    </div>
                                    <div id="collapseFour" class="panel-collapse collapse" role="tabpanel"
                                        aria-labelledby="headingFour" style="">
                                        <div class="panel-body">
                                            <p>Design innovative and functional spaces, ensuring aesthetic and structural excellence in all projects.</p>
                                            <ul class="text-dark">
                                                <li>Qualification: Graduate </li>
                                                <li>Min. Experience: 1 year</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingTwo">
                                        <h4 class="panel-title">
                                            <a class="collapsed" role="button" data-bs-toggle="collapse"
                                                data-bs-parent="#accordion" href="#collapseTwo" aria-expanded="false"
                                                aria-controls="collapseTwo"> Project Manager </a>
                                        </h4>
                                    </div>
                                    <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel"
                                        aria-labelledby="headingTwo">
                                        <div class="panel-body">
                                            <p>Oversee construction projects from planning to completion, ensuring timely delivery, quality, and cost efficiency.</p>
                                            <ul class="text-dark">
                                                <li>Qualification: Graduate </li>
                                                <li>Min. Experience: 8-10 year</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingThree">
                                        <h4 class="panel-title">
                                            <a class="collapsed" role="button" data-bs-toggle="collapse"
                                                data-bs-parent="#accordion" href="#collapseThree" aria-expanded="false"
                                                aria-controls="collapseThree"> Supervisor </a>
                                        </h4>
                                    </div>
                                    <div id="collapseThree" class="panel-collapse collapse" role="tabpanel"
                                        aria-labelledby="headingThree">
                                        <div class="panel-body">
                                            <p>Manage on-site activities, ensuring adherence to safety, quality standards, and project timelines.</p>
                                            <ul class="text-dark">
                                                <li>Qualification: Graduate </li>
                                                <li>Min. Experience: 4 year</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>

                                <!-- Site engineer -->
                                <div class="panel panel-default">
                                    <div class="panel-heading" role="tab" id="headingFive">
                                        <h4 class="panel-title">
                                            <a class="collapsed" role="button" data-bs-toggle="collapse"
                                                data-bs-parent="#accordion" href="#collapseFive" aria-expanded="false"
                                                aria-controls="collapseFive"> Site engineer </a>
                                        </h4>
                                    </div>
                                    <div id="collapseFive" class="panel-collapse collapse" role="tabpanel"
                                        aria-labelledby="headingFive">
                                        <div class="panel-body">
                                            <p>Manage on-site activities, ensuring adherence to safety, quality standards, and project timelines.</p>
                                            <ul class="text-dark">
                                                <li>Qualification: Graduate </li>
                                                <li>Min. Experience: 4-6 year</li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 wow slideInRight animated"
                        style="visibility: visible; animation-name: slideInRight;">
                        <form id="careers" action="" method="post" enctype="multipart/form-data"
                            class="contact-form formspace" novalidate="novalidate">
                            <div id="carnote">
                            </div>
                            <div class="row">
                                <div class="col-lg-6">
                                    <div class="contact-field p-relative c-name  inputWithIcon">
                                        <input type="text" name="name" placeholder="Name">

                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="contact-field p-relative c-email  inputWithIcon">
                                        <input type="text" name="email" placeholder="Email">

                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="contact-field p-relative c-phone  inputWithIcon">
                                        <input type="tel" name="phone" class="" placeholder="Phone No.">

                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="contact-field p-relative c-city  inputWithIcon">
                                        <input type="text" name="city" placeholder="City">

                                    </div>
                                </div>
                                <div class="col-lg-6 mb-2">
                                    <div class="contact-field p-relative c-history ">
                                        <div class="input-group  inputWithIcon">
                                            <select name="post" class="custom-select chooseop w-100 bg-light" id="inputGroupSelect01">
                                                <option value="">Select Apply For</option>
                                                <option value="Sales">Sales</option>
                                                <option value="Architect">Architect</option>
                                                <option value="Project Manager">Project Manager</option>
                                                <option value="Supervisor">Supervisor</option>
                                            </select>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-6">
                                    <div class="contact-field p-relative c-history ">
                                        <div class="input-group  inputWithIcon">
                                            <select name="experience" class="custom-select chooseop w-100 bg-light"
                                                id="inputGroupSelect02">
                                                <option value="">Select Experience</option>
                                                <option value="Less than 2 Years">Less than 2 Years</option>
                                                <option value="2-5 Years">2-5 Years</option>
                                                <option value="More than 5 Years">More than 5 Years</option>
                                            </select>

                                        </div>
                                    </div>
                                </div>
                                <div class="col-lg-12 mb-2">
                                    <div class="contact-field p-relative c-message  inputWithIcon">
                                        <textarea name="msg" id="message" style="height: 100px;"
                                            placeholder="Message"></textarea>

                                    </div>
                                </div>
                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <div class="file-upload-wrapper" data-text="Select your file!">
                                            <input name="files" id="fileUpload" type="file" accept=".pdf,.doc,.docx"
                                                class="file-upload-field" value="">
                                        </div>
                                        <label id="fileUpload-error" class="error" for="fileUpload"></label>
                                    </div>
                                </div>
                                <div class="col-lg-12 text-center mt-4">
                                    <button type="submit" id="submit_btn_2" class="border border-dark cm-bt1 text-dark">
                                        <span class="btn-title " id="submit_text">Submit</span>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <style type="text/css">
        a:hover,
        a:focus {
            text-decoration: none;
            outline: none;
        }

        #accordion .panel {
            border: none;
            box-shadow: none;
            border-radius: 10px;
            margin-bottom: 10px;
        }

        #accordion .panel-heading {
            padding: 0;
            border: none;
            border-radius: 10px;
        }

        #accordion .panel-title a {
            display: block;
            padding: 10px 35px;
            font-size: 20px;
            font-weight: 600;
            color: #000;
            background: black;
            color: white;
            border: none;
            position: relative;
            transition: all 0.3s ease 0s;
        }

        #accordion .panel-title a:after,
        #accordion .panel-title a.collapsed:after {
            content: "\f068";
            font-family: "FontAwesome";
            font-weight: 900;
            width: 40px;
            height: 40px;
            line-height: 32px;
            border-radius: 50%;
            background: black;
            color: white;
            text-align: center;
            font-size: 15px;
           
            border: 5px solid #fff;
            position: absolute;
            top: 5px;
            left: -20px;
            transition: all 0.3s ease 0s;
        }

        #accordion .panel-title a.collapsed:after {
            content: "\f067";
        }

        #accordion .panel-title a:hover:after,
        #accordion .panel-title a.collapsed:hover:after {
            transform: rotate(360deg);
        }

        #accordion .panel-body {
            padding: 15px 25px;
            /*background: #fff;*/
            font-size: 14px;
            color: black;
            color: white;
            line-height: 25px;
            border-top: none;
            position: relative;
        }

        #contacterrormessage1 p {
            margin: 0 !important;
        }
    </style>




    <?php
    include 'footer.php';
    ?>